dojo.require("dojo.fx");
var breite = window.innerWidth-450;
 
    dojo.ready(function(){
        var slideAwayButton_layer = dojo.byId("slideAwayButton_layer"),
            slideBackButton_layer = dojo.byId("slideBackButton_layer"),
            slideTarget_layer = dojo.byId("slideTarget_layer"),
			
			slideAwayButton_classes = dojo.byId("slideAwayButton_classes"),
            slideBackButton_classes = dojo.byId("slideBackButton_classes"),
            slideTarget_classes = dojo.byId("slideTarget_classes"),
		    
			slideAwayButton_legend = dojo.byId("slideAwayButton_legend"),
            slideBackButton_legend = dojo.byId("slideBackButton_legend"),
            slideTarget_legend = dojo.byId("slideTarget_legend");
		
		
		
		dojo.connect(slideAwayButton_layer, "onclick", function(evt){
            dojo.fx.combine([
                dojo.fadeIn({ node: slideTarget_layer }),
                dojo.fx.slideTo({ node: slideTarget_layer, left: breite, top: "0" })
            ]).play();
        });
        dojo.connect(slideBackButton_layer, "onclick", function(evt){
            dojo.fx.combine([
                dojo.fx.slideTo({ node: slideTarget_layer, left: breite+500, top: "0" }),
                dojo.fadeOut({ node: slideTarget_layer })
            ]).play();
        });
		
		dojo.connect(slideAwayButton_classes, "onclick", function(evt){
            dojo.fx.combine([
                dojo.fadeIn({ node: slideTarget_classes }),
                dojo.fx.slideTo({ node: slideTarget_classes, left: breite, top: "220" })
            ]).play();
        });
        dojo.connect(slideBackButton_classes, "onclick", function(evt){
            dojo.fx.combine([
                dojo.fx.slideTo({ node: slideTarget_classes, left: breite + 500, top: "220" }),
                dojo.fadeOut({ node: slideTarget_classes })
            ]).play();
        });
		
		
		dojo.connect(slideAwayButton_legend, "onclick", function(evt){
            dojo.fx.combine([
                dojo.fadeIn({ node: slideTarget_legend }),
                dojo.fx.slideTo({ node: slideTarget_legend, left: "10", top: "300" })
            ]).play();
        });
        dojo.connect(slideBackButton_legend, "onclick", function(evt){
            dojo.fx.combine([
                dojo.fx.slideTo({ node: slideTarget_legend, left: "-500", top: "300" }),
                dojo.fadeOut({ node: slideTarget_legend })
            ]).play();
        });
		
    });

	

	
	

	
	
	