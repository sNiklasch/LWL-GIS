Shadowbox.init({
    // let's skip the automatic setup because we don't have any
    // properly configured link elements on the page
    skipSetup: true
});

window.onload = function() {

    // open a welcome message as soon as the window loads
    Shadowbox.open({
        content:    '<div id="welcome-msg" style="color:white;font-family:verdana">
		
		
		
		<b>Wilkommen im LWL Web-GIS!</b><br/></br>

<a href="http://www.lwl.org" target="_blank"><img src="images/lwl_logo_klein.png" align="right" vspace="5" hspace="5" alt="LWL"></a>
<a href="http://ifgi.uni-muenster.de" target="_blank"><img src="images/ifgi_logo_klein.png" align="right" vspace="5" hspace="5" alt="IFGI"></a>

Dieses online Geo-Informationssystem �ber Westfalen wurde in Kooperation mit dem Landschaftsverband Westfalen Lippe und dem Institut f�r Geoinformatik erstellt.
<br/><br/>

Sie haben hier die M�glichkeit sich zu verschiedenen Themenbereichen eigene Karten von den Verwaltungsbezirken in Westfalen zu erstellen. Experimentieren sie selbst
mit verschiedenen Farben und Klassengrenzen, bis das Ergebnis optisch ihren W�nschen entspricht!
<br/><br/>
Viel Spa�!
		
		
		
		
		
		
		</div>',
        player:     "html",
        title:      "Wilkommen",
        height:     350,
        width:      600
    });

};





